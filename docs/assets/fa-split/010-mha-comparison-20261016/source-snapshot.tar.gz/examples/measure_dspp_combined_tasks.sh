#!/bin/bash
# One paired run by default; reverse order explicitly only if results warrant it.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${DSPP_COMBINED_MEASURE_ROOT:?set a new output directory}"
: "${DSPP_COMBINED_DATA_PATH:?set the existing input dataset prefix}"
PYTHON_BIN=${PYTHON_BIN:-/workspace/src/venvs/megatron/bin/python}
query_groups=${DSPP_COMBINED_QUERY_GROUPS:-2}
[[ "$query_groups" == 1 || "$query_groups" == 2 || "$query_groups" == 4 ]]
# With four Q heads, four KV heads is MHA: omit the GQA switch entirely.
if [[ "$query_groups" == 4 ]]; then query_groups=; fi
test ! -e "$DSPP_COMBINED_MEASURE_ROOT"
read -ra modes <<< "${DSPP_COMBINED_MODE_ORDER:-fused after_dx}"
[[ "${modes[*]}" == 'fused after_dx' || "${modes[*]}" == 'after_dx fused' ]]
mkdir -p "$DSPP_COMBINED_MEASURE_ROOT"
for mode in "${modes[@]}"; do
  out="$DSPP_COMBINED_MEASURE_ROOT/$mode"
  mkdir -p "$out"
  split=0
  if [[ "$mode" == after_dx ]]; then split=1; fi
  TRAIN_ITERS=3 HIDDEN_SIZE=512 FFN_HIDDEN_SIZE=1024 NUM_ATTENTION_HEADS=4 NUM_QUERY_GROUPS="$query_groups" \
  NUM_LAYERS=6 LAYERS_PER_VPP=1 SEQ_LENGTH=8192 MICRO_SEQ_LENGTH=2048 \
  MICRO_BATCH_SIZE=4 GLOBAL_BATCH_SIZE=8 DSPP_DEBUG_BATCHES=0 LEARNING_RATE=0 MIN_LEARNING_RATE=0 \
  DATA_PATH="$DSPP_COMBINED_DATA_PATH" DSPP_TASK_TIMING_ONLY=1 \
  DSPP_SPLIT_ATTENTION_BACKWARD="$split" DSPP_HISTORY_DKV_AFTER_DX="$split" \
  DSPP_TIMELINE_DIR="$out/timeline" DSPP_TIMELINE_ITERATION=3 \
  PYTHON_BIN="$PYTHON_BIN" TRAIN_ENTRYPOINT=pretrain_llama.py \
    timeout 300 bash examples/run_dspp_b23_l40.sh > "$out/train.log" 2>&1
done
"$PYTHON_BIN" tools/summarize_dspp_history_tasks.py --root "$DSPP_COMBINED_MEASURE_ROOT" --modes fused after_dx

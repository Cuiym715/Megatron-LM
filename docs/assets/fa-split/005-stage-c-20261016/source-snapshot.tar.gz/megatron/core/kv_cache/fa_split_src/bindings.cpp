// Experimental FA2 backward split. Production FlashAttention is not replaced.
#include <torch/extension.h>

at::Tensor split_prepare(const at::Tensor&, const at::Tensor&, const at::Tensor&,
                         const at::Tensor&, const at::Tensor&, const at::Tensor&, double);
at::Tensor split_dq(const at::Tensor&, const at::Tensor&, const at::Tensor&,
                    const at::Tensor&, const at::Tensor&, const at::Tensor&,
                    const at::Tensor&, double);
std::vector<at::Tensor> split_dkv(const at::Tensor&, const at::Tensor&, const at::Tensor&,
                                const at::Tensor&, const at::Tensor&, const at::Tensor&,
                                const at::Tensor&, double, int64_t, int64_t);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("prepare", &split_prepare);
    m.def("dq", &split_dq);
    m.def("dkv", &split_dkv);
}

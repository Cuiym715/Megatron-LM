# DSPP 历史 dKV：FA backward 拆分实现计划

更新日期：2026-10-16  
状态：阶段 A、B、C 已实现并通过各自限定范围内的 GPU 正确性验收。代码基点：`abd39e566`（`cuiym-dspp`），本轮改动尚未提交。阶段 A 历史记录见 §9–10，阶段 B 见 §11–12，阶段 C 当前集成功能与真实训练验证见 §13。历史 dKV 仍立即执行，没有实现跨任务延后。

## 1. 本轮目标与文档职责

本轮只实现并验证 attention backward 的正确拆分：保留 FA 前向，提供独立的 dQ 和指定 KV 区域 dK/dV 计算入口，支持 MHA/GQA，最终接入 DSPP packed backward。历史部分仍在同一次 backward 内立即执行完毕，再返回梯度。

不在本轮开展性能补采、成本测量、调度重放或跨任务延后，也不以完整 stage dx 提前或 iteration 加速作为本轮交付。正确性测试所需的 GPU 执行属于本轮验证，不等于性能实验。

本文记录代码实现计划、阶段验收和最终已实现能力。项目外层 `docs/v4/design/history-dkv/plan.md` 继续承担研究收益验证计划的职责；其中原有“推演后再原型”的安排不作为本轮正确拆分开发的前置条件。本文不修改外层 design.md。

## 2. 开发前的代码依据

- `megatron/core/kv_cache/dspp_packed_attention.py`：`_DsppPackedFlashAttention.backward` 调用一次完整 `_wrapped_flash_attn_varlen_backward`，然后通过 `distribute_key_value_grads` 分发已经算好的历史梯度，并合并当前 segment 收到的贡献。尚无独立 D/H 执行接口。
- `megatron/model/transformer.py`：FA 分支直接传入 Q/K/V；GQA 的 KV heads 没有在该分支展开为 Q heads。新实现应保持这一紧凑布局。
- `tests/unit_tests/dspp/test_packed_attention.py`：现有基础 Q/K/V 测试构造使用相同 head 数，不足以证明 GQA 的拆分与历史累加正确性。
- 已有运行环境记录使用 FlashAttention `2.7.4.post1`。开发前还需核对实际安装版本、源码对应关系、CUDA/PyTorch ABI 和目标 GPU，不能仅凭版本名确定修改位置。

首轮固定 CP=TP=DP=1、BF16、causal、dropout=0、无 activation checkpoint，先支持 head dimension 128。RoPE 沿用现有非 fast 路径；后续测试可扩展 head dimension，但未验证组合须显式拒绝或清晰记录，不能悄悄以融合路径代替拆分后宣称通过。

## 3. 执行方式：建议三个阶段交付

此前讨论的四个技术步骤不建议一次全部执行。将“接口与参考实现”和“基础 MHA kernel 拆分”合为阶段 A；区域/GQA 为阶段 B；接入现有 backward 为阶段 C。每阶段内部连续完成代码、正确性测试和结果记录，阶段末汇报，再由用户决定是否推进下一阶段。

| 阶段 | 对应技术步骤 | 可独立验收的交付 | 本阶段结束时不代表什么 |
| --- | --- | --- | --- |
| A：基础 FA 拆分 | 原步骤 1、2 | 独立 dQ/dKV GPU 入口，MHA 单序列正确性通过 | 不代表历史区域选择、GQA 或 DSPP 集成完成 |
| B：区域与 GQA | 原步骤 3 | 当前/历史 KV 区域选择，原生 GQA/MQA 和 varlen 边界正确性通过 | 不代表真实模型的历史梯度路由已经接入 |
| C：DSPP 集成 | 原步骤 4 | 拆分路径可开关，packed、RoPE、历史累加及多层梯度验证通过 | 不代表历史计算已跨任务延后，也不代表性能改善 |

用户先后明确要求“执行阶段 A”“执行阶段 B”和“执行阶段 C”，目前已完成 A/B/C。本次授权范围是拆分集成与正确性验证，后续跨任务延后和收益实验另行确定。

## 4. 拆分合同

### 4.1 接口与状态

以下是拟定接口职责，名称可在实现时调整：

```text
prepare_backward(Q, K, V, O, dO, LSE, metadata) -> backward_state
backward_dq(backward_state)                   -> 完整 dQ
backward_dkv(backward_state, kv_regions)      -> 指定区域 dK/dV
```

`backward_state` 显式持有所需 tensor、cu_seqlens、每序列 Q/K 长度、scale、dtype、head 映射和区域坐标。预处理计算一次 `delta = rowsum(dO * O)`；具体 LSE/delta 布局和数值精度须与所用 FA 内核对齐。区域不能依赖后续可变化的 `state.current_meta`。

正式实现保持分块融合与局部重计算，不生成完整 S/P/dS 矩阵。小规模稠密实现仅作为独立正确性参照。不能调用完整 FA backward 后丢弃 dKV 来冒充独立 dQ，也不能先算完历史 dKV 再仅把其路由推迟。

### 4.2 D/H 分工

- D：完整 dQ，加当前 KV 区域的 dK/dV。完整 dQ 必须包含全部合法历史区域的贡献。
- H：当前 query 对全部历史 KV 区域的 dK/dV。
- 首版 D 可由 `backward_dq(all)` 和 `backward_dkv(current)` 两个 kernel 路径组成，H 调用 `backward_dkv(history)`。不要求 D 融合成一次启动，也不承诺整个 backward 只有两次 kernel 启动。
- 首版只支持全部历史/当前的划分，不实现任意历史子集选择。无历史时 H 为显式空操作，dQ 和当前 dKV 仍必须完整。
- 两部分使用同一份完整上下文 LSE 和 delta；不能在 KV 子区域上独立归一化。简单拆法也可能在当前区域重复生成中间量，不能直接套用特定拆分区域的“5→7”作为实际执行成本。

## 5. 阶段 A：独立 dQ/dKV 的 MHA 基础实现

1. 核查 FA2 backward 的预处理、mainloop、dQ 累加/转换及 dKV 输出路径，固定源码版本和可复现构建入口。
2. 优先基于当前 FA2 对应 CUDA 实现建立独立扩展，保留其分块计算机制。新增源码/补丁、版本锁定、构建说明及许可证信息纳入仓库；不直接修改环境中的安装文件作为最终交付，不替换整个环境的默认 FA。
3. 实现独立 dQ 和完整 KV 范围的 dKV 入口，显式初始化累加工作区并完成必要转换。先支持单序列 MHA、causal、无历史区域选择；依次立即执行两个入口。
4. 建立小规模高精度数学参考，用非平凡随机 dO 对照梯度；同时与原 FA 前向/融合 backward 比较 BF16 结果。

验收：扩展可按记录构建，两个入口独立调用有效，合并输出的 dQ/dK/dV 正确；重复调用无残留梯度。未经证实的 CUDA 源码可复用性若阻碍实现，应先报告具体障碍和替代实现方式，不悄悄换成稠密 GEMM 版本后称为 FA 拆分。

阶段 A 不修改生产 custom autograd、KV 路由或 pipeline scheduler。接口从一开始区分 Hq/Hkv，但本阶段仅声明 MHA 已验收。

## 6. 阶段 B：历史区域与原生 GQA

### 6.1 区域、varlen 与 causal 坐标

先在 MHA 上加入每序列的当前/历史 KV 区域：设历史长度为 h，局部 query 位置 a 对应完整序列位置 h+a，key 位置 b 的合法条件为 `b <= h+a`。区域限制只选择输出的 KV 位置，不能错误裁剪完整 dQ 所需的历史扫描。

支持每序列独立 cu_seqlens、短尾、非 tile 对齐的区域边界，以及多个独立序列组成的 varlen 输入。首版允许各区域写入一个完整形状梯度 buffer 的互不重叠位置，以便后续复用路由；必须明确哪些区域已经写完，不能将未初始化位置交给消费者。

验收：当前与历史区域无重叠、无遗漏，二者组成完整 dKV；无历史、全历史前缀、短尾和边界 tile 均正确，不串序列。

### 6.2 GQA head 映射与归约

要求 `Hq % Hkv == 0`，令 `r = Hq / Hkv`。现有模型的分组布局下，Q head q 映射到 KV head `g = floor(q/r)`：

```text
dQ[q] 使用 K[g]、V[g]，保留 Q-head 维度
dK[g] = sum(dK_from_q[q] for q in group(g))
dV[g] = sum(dV_from_q[q] for q in group(g))
```

LSE/delta 仍按 Q head 索引；每个 Q head 有自己的概率与梯度，不能在计算前对 Q heads 取平均，也不能将 dKV 的组内求和误写为平均。

优先采用明确的部分梯度工作区加归约步骤，核对是否可复用 FA 原有 GQA 归约，保证只归约一次。工作区精度、清零、写入所有权、归约顺序及输出转换均须明确；正式路径不复制 K/V heads。参考实现可显式展开 KV，并由 autograd 归约，作为独立 oracle。

验收至少覆盖 `(Hq,Hkv)=(16,16)、(16,8)、(16,4)、(16,1)`，并与历史/当前区域划分、varlen/非对齐边界组合。使用组内不同的 Q/dO，暴露漏加、重复加及错误 head 映射。

阶段 B 可先交付区域划分，再交付 GQA；二者都通过才标记整个阶段完成。

## 7. 阶段 C：接入 DSPP packed backward

在 `_DsppPackedFlashAttention.backward` 增加实验路径，执行顺序为：

```text
prepare delta
  -> 完整 dQ
  -> 当前区域 dKV
  -> 历史区域 dKV
  -> distribute_key_value_grads
  -> 返回当前 Q/K/V 梯度
```

保留原融合路径为默认值，通过明确开关选择拆分。先复用现有 assembled dKV buffer 与 `distribute_key_value_grads`，不同时重写缓存协议。两部分均写完后才调用路由，因此此阶段无异步 pending 状态或跨任务 H 队列。

需要保证：

1. 当前 segment 的 dK/dV 在返回前合并后续 chunks 已产生的贡献；每份历史贡献只入账一次。
2. GQA 的历史缓存/累加缓冲保持 Hkv 维度；已归约的 dKV 不再次执行 Q-head 归约。
3. dK 在当前实现的 RoPE 反向入口之前合并，不对历史梯度重复或遗漏旋转反向。
4. physical padding 的梯度为零；输出保持原 Q/K/V 物理形状，包括不同 head 数。
5. 多层、不同 logical microbatch 和连续 iteration 的状态隔离正确，缓存按现有逆序反向合同排空。

验证从独立 attention 扩展到带 RoPE、QKV/输出投影的模块，再到多层 backward：比较输出、输入梯度及参数梯度。覆盖 continuation 加短序列混装、多源向同一目标累加和连续 iteration；最后在现有支持的 PP 路径做正确性 smoke，不采性能或开展调度实验。

完成后可声明“FA backward 已拆分，支持经测试的 GQA/packed 配置，历史部分立即执行”。不能声明“完整 stage dx 已提前”或“历史 dKV 已延后”。

## 8. 验证与结果记录规则

数值验收同时参考高精度数学实现与原融合 FA；根据 dtype 和原路径自身误差预先确定容限，报告最大绝对误差及适当的相对/范数误差，不用近零元素的相对误差单独判定。浮点归约顺序变化允许合理舍入差异，不要求逐位相等，也不能为通过测试临时放宽容限。

GPU 测试被 skip、仅 Python 接口可调用或只有 CPU 公式通过，均不算 kernel 验收完成。保留原融合路径回归测试，验证默认行为未变。每阶段汇报修改文件、已支持形状、执行环境、测试命令/结果和限制。

| 项目 | 状态 | 已验证功能／证据 |
| --- | --- | --- |
| 实现计划 | 已写入并更新，2026-10-16 | 本文 |
| A：MHA 独立 dQ/dKV | 已完成 | 独立 CUDA 入口；29 项拆分正确性测试、10 项原路径回归通过；详见 §9 |
| B：区域与 GQA | 已完成 | 当前／历史区域、逐序列 varlen 分派、原生 GQA/MQA；60 项阶段 B 测试通过，详见 §11 |
| C：DSPP 集成 | 已完成（限定范围） | 默认关闭的 packed backward 拆分；RoPE／投影／多层、真实 PP=3/VPP=2 的 MHA/GQA/MQA 训练对照通过，详见 §13 |

最终实现功能与限制集中更新本表及相应阶段，不另建重复报告。性能测量、重放与真正延后执行在正确拆分验收后另行确定。

## 9. 阶段 A 实现与验收（2026-10-16）

### 9.1 实际实现

新增独立实验模块，生产 `dspp_packed_attention.py`、KV 路由和 pipeline scheduler 均未修改：

| 文件 | 职责 |
| --- | --- |
| [fa_split.py](../megatron/core/kv_cache/fa_split.py) | `prepare_backward`、`backward_dq`、`backward_dkv`；状态持有、修改检测和同 stream 合同 |
| [backward.cu](../megatron/core/kv_cache/fa_split_src/backward.cu)／[bindings.cpp](../megatron/core/kv_cache/fa_split_src/bindings.cpp) | 三个独立 GPU 操作的参数校验、工作区分配和调用入口 |
| [flash_bwd_split.patch](../megatron/core/kv_cache/fa_split_src/flash_bwd_split.patch) | 为原 FA2 column-block backward 增加编译期开关，真正裁掉不需要的梯度 GEMM 和写回 |
| [fa_split_build.py](../megatron/core/kv_cache/fa_split_build.py)／[构建脚本](../tools/build_dspp_fa_split.py) | 锁定依赖、校验源码、在缓存目录生成补丁头文件与独立扩展 |
| [test_fa_split.py](../tests/unit_tests/dspp/test_fa_split.py) | 与融合 FA、独立 FP64 autograd 参考比较，检查边界和状态合同 |

源码固定为 FA `v2.7.4.post1` / `5231d95fe13733fb534c01895f7ea88c6a6c7793`、CUTLASS `c506e16788cb08416a4a57e11a9067beeee29420`。源码版本、原始头文件 SHA256 和许可证见 [upstream.json](../megatron/core/kv_cache/fa_split_src/upstream.json)、[THIRD_PARTY.md](../megatron/core/kv_cache/fa_split_src/THIRD_PARTY.md) 及同目录许可证文件。安装环境中的 FA 不被替换，显式 `--fetch` 才获取依赖；正常调用只使用已经取得的固定源码。

实际执行分工：

- prepare 复用 FA2 的 `compute_dot_do_o`，计算一次 FP32 delta。
- dQ-only 复用分块 P/dS 重计算与 dQ GEMM，禁用 dK/dV GEMM 及写回；每次调用独立清零 FP32 dQ 累加缓冲，再调用原 FA2 转换 kernel。
- dKV-only 复用分块 P/dS 重计算与 dK/dV GEMM，禁用 dQ GEMM 和累加写回；不分配 dQ 输出或累加缓冲，可先于 dQ 独立调用。
- 采用 FA2 在 L40 上的 BF16/head-dim-128 tile 配置；保留共有的加载/同步结构，不宣称已完成各分支性能调优。没有完整 S/P/dS 显存矩阵，也没有调用完整 backward 后丢弃梯度的替代实现。

### 9.2 已支持范围与限制

接口输入为单序列 `[S,H,128]` 连续 BF16 Q/K/V/O/dO，Q/K 长度相等、MHA；LSE 为匹配 FA 前向输出的连续 FP32 `[H,S]`，使用自然对数。前向必须为全上下文 causal、dropout=0、无 softcap/ALiBi/local window，softmax scale 与 backward 一致。

本轮验证 NVIDIA L40（SM89）、PyTorch `2.10.0a0+a36e1d39eb.nv26.01.42222806`、CUDA toolkit 13.1、FA `2.7.4.post1`、Python 3.12。扩展按当前 GPU 架构构建，其他架构没有本轮验证结论。

GQA/MQA、不同 Q/K 长度、varlen、多序列 packing、历史区域选择与生产 autograd 集成仍未支持。输入不符时显式报错，不回退为原融合路径假装拆分。接口不提供高阶 autograd；调用者必须提供来自同一前向的 O/LSE/scale，不能只凭形状判断它们的语义匹配。

prepare/dQ/dKV 必须在同一 CUDA stream 执行；允许非默认 stream，也验证了当前设备不同于输入设备的情形。状态 tensor 持有引用并检查版本，调用间不得修改；这不是后续异步延后所需的完整生命周期协议。dQ 沿用 FP32 原子累加，不承诺逐位确定性。

### 9.3 正确性结果与数值边界

机器可读结果及原始测试输出归档于 [001-stage-a-20261016](assets/fa-split/001-stage-a-20261016/)。没有采集 iteration 性能或 profiler trace。

- 新增测试 **29 passed、0 skipped**：覆盖 S=1/17/63/64/65/127/128/129/257/513，H=1/2/4/16，自定义 scale、随机 dO、零 dO、两入口不同调用顺序、重复调用、状态不被改写、修改检测、非法配置、非默认 stream 及跨设备 guard。
- 原 `test_packed_attention.py`、`test_kv_state.py` 回归 **10 passed、0 skipped**。
- Compute Sanitizer 仅检查新扩展的 `dspp_split_detail` kernels：memcheck 的普通形状/重复调用 **12 passed、0 errors**；racecheck 的重复调用 **1 passed、0 hazards**。这覆盖所选用例的越界/内存访问和 shared-memory 竞态检查，不是全配置无缺陷证明。
- 数值结果来自 11 组普通形状/scale 和 3 组较大输入幅度的 seed。最终普通测试运行中 dK/dV 与原融合 FA 逐位一致；dQ 对原 FA 最大绝对差 `9.765625e-4`，最大相对 L2 差约 `1.995e-5`。dQ 的小差异与原子累加顺序有关，此处不是确定性保证。
- 对独立 FP64 数学参考，非零梯度的最大相对 L2 误差分别为 dQ `0.004786`、dK `0.004675`、dV `0.002305`；这是所测样例的数值误差，不是性能指标。S=1 的数学零 dQ/dK 单独检查绝对误差 `<=1e-5`，相对误差记为 null。

**保留的验收修正依据：** 首轮预设普通输入的 FP64 逐元素 `atol=rtol=0.04`，对幅度为 2、S=65/H=2/seed=1234 的压力样例，拆分 dQ/dK 未通过。独立复核发现原融合 FA 也未通过同一阈值，且该样例三项拆分梯度与原 FA 完全一致；原/拆分的 dQ、dK 最大绝对误差分别约 `0.08503`、`0.09683`。没有改 kernel 掩盖该现象，也没有放宽普通样例阈值。

因此压力样例单列：要求与原融合 FA **逐位相等**，同时保持对 FP64 的相对 L2 `<=0.012`，再用 seed=2026/17 验证。三组均通过。普通样例继续使用原来的融合对照 `atol=0.004/rtol=0.01` 和 FP64 逐元素/范数条件；不能把 BF16 梯度描述为与 FP64 精确相同。

### 9.4 构建与复现

在 GPU 可访问、依赖齐全的环境中，从仓库根目录执行：

```bash
python tools/build_dspp_fa_split.py --fetch
python -m pytest -q -s tests/unit_tests/dspp/test_fa_split.py
python -m pytest -q tests/unit_tests/dspp/test_packed_attention.py tests/unit_tests/dspp/test_kv_state.py
compute-sanitizer --tool memcheck --error-exitcode 99 --kernel-name kns=dspp_split_detail \
  python -m pytest -q tests/unit_tests/dspp/test_fa_split.py -k 'matches_fused or repeat_zero'
compute-sanitizer --tool racecheck --error-exitcode 99 --kernel-name kns=dspp_split_detail \
  python -m pytest -q tests/unit_tests/dspp/test_fa_split.py -k repeat_zero
```

需要 C++/CUDA 编译器、ninja、git、patch、PyTorch、pytest、现有 Megatron Python 依赖和 FA。默认依赖/构建缓存为 `~/.cache/dspp-fa-split`，可用 `DSPP_FA_SPLIT_CACHE` 指定；`MAX_JOBS=2` 可限制编译并行度。导入模块不会下载依赖，首次显式使用会构建/加载缓存中的扩展。

本轮使用独立临时容器 `nvcr.io/nvidia/pytorch:26.01-py3`，挂载 `/home/cuiym:/workspace`，工作目录 `/workspace/src/Megatron-LM-kwai`，Python 为 `/workspace/src/venvs/megatron/bin/python`。以宿主 UID/GID 1001 运行，设置 `USER=cuiym`（该 UID 未登记在镜像 passwd）、`TORCHINDUCTOR_CACHE_DIR=/tmp/dspp-split-inductor`、`DSPP_FA_SPLIT_CACHE=/workspace/.cache/dspp-fa-split`，pytest 使用可写的 `/tmp` cache_dir。原训练容器未重启或修改。

阶段 A 到此结束。下一阶段是区域划分和 GQA，需按后续指令推进；当前没有历史 dKV 跨任务延后、完整 stage dx 提前或端到端收益结论。

## 10. 阶段 A 的可视化执行证据（2026-10-16）

用户在阶段 A 验收后要求提供执行图和更直观的结果，因此补充一次独立 attention 的真实 profiler 采样。它不扩展到阶段 B/C，不修改 kernel、模型或生产调度，也不是变长负载/iteration 性能基线。

### 10.1 真实 GPU 时间线

固定 L40、BF16、S=2048/H=16/d=128、causal、dropout=0，使用相同随机 Q/K/V/dO（seed=1234）。预热后采集五个执行样例：原融合路径、dQ→dKV、dKV→dQ、仅 dQ、仅 dKV。每例都使用原 FA 前向；拆分例计算共享 delta。通过 CUDA runtime correlation 将 GPU kernel 对应到标记范围，记录真实设备起止时间，不用 CPU 标签宽度冒充 GPU 执行时间。

![实际 GPU 执行与独立 kernel 启动次数](assets/fa-split/002-execution-evidence-20261016/gpu_execution.png)

采到的独立主 kernel 名称是 `dspp_split_detail::split_kernel<true>`（dQ）和 `split_kernel<false>`（dKV）。程序检查了它们与原融合 main kernel 的启动次数：

| 执行样例 | 独立 dQ 主 kernel | 独立 dKV 主 kernel | 原融合主 kernel |
| --- | ---: | ---: | ---: |
| 原 FA | 0 | 0 | 1 |
| dQ→dKV | 1 | 1 | 0 |
| dKV→dQ | 1 | 1 | 0 |
| 仅 dQ | 1 | 0 | 0 |
| 仅 dKV | 0 | 1 | 0 |

仅 dKV 时也没有启动 dQ 转换 kernel。这些设备执行记录与 §9 的编译期计算裁剪共同支持“已独立拆分”，不只是增加两个 Python 标签。

**图的范围：** F_attn 只是 attention 前向，B_attn 只是 attention backward。完整 stage B 还包含其他层、投影等反向，W 是参数梯度任务，阶段 A 未接入它们。橙色表示完整 dKV，不是已经选出来的历史贡献 H。因此当前不能画一张真实的“完整 F/B/W＋历史 H”训练图，也不能将绿色 dQ 的结束标为完整 stage dx 就绪。

本次单个 profiler 样例中，原融合主计算 kernel 约 358.91 μs；顺序拆分的 dQ 主 kernel 约 263.01 μs、dKV 主 kernel 约 300.96 μs，另有预处理、清零、转换和间隔。它明确没有给出加速证据。这里的数字仅说明本次执行记录，不能当作稳定成本基准；不能用两行总跨度的差推导加速比，或把空白当作可插入历史任务的空隙。

### 10.2 独立调用与数值结果

本次 S=2048/H=16 的所有拆分执行方式都通过原融合 FA 对照：dK/dV 逐位相同；dQ 最大绝对差 `4.8828125e-4`，最大相对 L2 差 `1.145e-5`。仅 dQ 和仅 dKV 的结果也分别通过对应梯度比较；dKV 先执行不依赖 dQ 的调用完成。

另外，将 §9 已归档的 14 组数值结果绘图，展示原融合/拆分 BF16 backward 对同一个独立 FP64 数学参考的误差。S=1 的数学零梯度用绝对误差验收，未放入相对误差图。

![原融合与拆分的梯度误差](assets/fa-split/002-execution-evidence-20261016/gradient_accuracy.png)

绿点与灰圈基本重合，支持所测样例没有因拆分显著损失精度；BF16 本身仍有舍入误差。此前压力样例的初始失败及单列验收理由仍保留在 §9.3，没有删除或改写为全部初次通过。

### 10.3 材料与复现

新增 [trace_dspp_fa_split.py](../tools/trace_dspp_fa_split.py) 和 [plot_dspp_fa_split.py](../tools/plot_dspp_fa_split.py)。[002 归档](assets/fa-split/002-execution-evidence-20261016/) 保存 GPU 事件及 kernel 全名、correlation、梯度比较、图片 PNG/SVG、文件校验值与运行输出。

在 §9.4 的 GPU 环境中运行（输出目录必须尚不存在）：

```bash
python tools/trace_dspp_fa_split.py --output /tmp/fa-split-evidence --length 2048 --heads 16
python tools/plot_dspp_fa_split.py \
  --evidence /tmp/fa-split-evidence/evidence.json \
  --validation docs/assets/fa-split/001-stage-a-20261016/validation.json \
  --font /path/to/NotoSansCJK-Regular.ttc
```

本机原始 `execution.pt.trace.json` 可用 Perfetto 等 trace viewer 打开，按现有 `.gitignore` 不进入普通 Git 提交；其 SHA256 保存在 `evidence.json`。可提交的 `evidence.json` 已保存绘图使用的全部 GPU 事件，原始 CPU/GPU trace 可通过脚本重新采集。上述 kernel 时间线是新增采样，梯度误差图则复用 001 的已有结果，两者不混作同一实验。

## 11. 阶段 B 实现与验收（2026-10-16）

阶段 B 已完成，阶段 C 未开始。本节描述当前代码；§9–10 保留阶段 A 当时的实现范围和测量，不能将旧时间线当作本版性能结果。实现仍是独立 attention backward，没有接入生产 autograd、历史梯度路由或 pipeline scheduler。

### 11.1 新增能力与执行依据

- **当前／历史区域：** `backward_dkv(state, region="all"|"current"|"history")`。每条序列的历史长度为 `Sk-Sq`，Q 对应 KV 的末尾当前区域；允许 `Sk>=Sq`，沿用 FA2 的 bottom-right causal mask。`backward_dq` 始终扫描全部合法 KV，两种区域共享同一次完整前向的 O/LSE 和 delta，不在子区域重新归一化。
- **实际计算范围：** CUDA launcher 仅启动与所选区域相交的 64-token KV tiles。非对齐边界最多使当前／历史两次调用重复一个边界 tile；边界多算位置不写入返回梯度。输出保持完整 `[Sk,Hkv,128]`，未选区域严格为零，因此当前与历史结果可直接相加。空历史返回全零，不启动 dKV 主 kernel；首版没有任意历史子集选择。
- **原生 GQA/MQA：** 使用 FA2 原有的 `q_head // (Hq/Hkv)` 访问紧凑 K/V，不复制输入 heads。复用原 FA2 backward API 的梯度精度合同：main kernel 在 FP32 累加每个 Q head 的 dKV，转换为 BF16 部分梯度工作区；ATen 按组以 FP32 求和、最终转换为 BF16，每份贡献只归约一次。区域选择后只读取已写入的工作区行，返回 Hkv 维度梯度。
- **变长：** `prepare_backward(..., cu_seqlens_q=..., cu_seqlens_k=...)` 接受整数 tuple/list 或 CPU／同 GPU 的 int32/int64 tensor；输入为 `[total_tokens,heads,128]`，LSE 为 `[Hq,total_q]`。首版逐序列调用原生 CUDA kernels，并拼接梯度，未实现单次批量 varlen 启动。CUDA 边界数据在 prepare 时同步到主机，冻结为不可变坐标；各序列使用自己的完整上下文 LSE、历史长度和 causal 偏移。
- **状态合同：** 保留同 stream、设备 guard、tensor 版本检测；增加原始 packed LSE、metadata tensor 和逐序列 delta 的修改检测。只接收严格递增的序列边界，拒绝空序列、`Sk<Sq`、非法 head 比例；空历史合法。BF16、head dim 128、causal、dropout=0 等限制沿用前述合同。

修改集中在 [fa_split.py](../megatron/core/kv_cache/fa_split.py)、[backward.cu](../megatron/core/kv_cache/fa_split_src/backward.cu)、[bindings.cpp](../megatron/core/kv_cache/fa_split_src/bindings.cpp)。原 FA header 的拆分补丁没有变化；新增 [test_fa_split_regions.py](../tests/unit_tests/dspp/test_fa_split_regions.py)，原测试中“拒绝合法 GQA”改为“拒绝 Hq 不能被 Hkv 整除”，原阶段 A 的数值容限不变。

首版有逐序列分派、输出置零／拼接和完整形状的部分梯度工作区；工作区规模为每序列两份 `[Sk,Hq,128]` BF16，而非 Hkv 大小。这些是明确的实现成本，当前没有调优或收益结论。部分梯度工作区不等于复制 K/V 输入，也不是保存完整 S/P/dS。

### 11.2 GPU 验证结果

环境仍为 L40 SM89、PyTorch `2.10.0a0+a36e1d39eb.nv26.01.42222806`、CUDA 13.1、FA `2.7.4.post1`；使用独立临时容器 `dspp-fa-split-stage-b`，原训练容器不变。本版扩展缓存标识 `e10d6e9353428102`。原始输出、机器可读结果、源码身份和启动检查归档于 [003-stage-b-20261016](assets/fa-split/003-stage-b-20261016/)。

| 验证 | 结果与范围 |
| --- | --- |
| 阶段 B 新测试 | **60 passed，0 skipped**：28 组单序列区域/GQA/FP64 对照、12 组 varlen 对照与隔离、2 组长上下文 GQA/MQA，以及状态、非法输入、stream／device、启动范围检查 |
| 阶段 A 与生产路径回归 | **29＋10 passed，0 skipped**；合计 **99 passed** |
| memcheck | 41 项区域/GQA/varlen/重复调用通过；过滤检查新扩展 kernels，**0 errors** |
| initcheck | 4 项 CUDA metadata 的 varlen MHA/GQA/MQA 通过；不做 kernel 名过滤，包含归约和拼接，**0 errors** |
| racecheck | 1 项 GQA 区域重复调用通过；检查新扩展 kernels，**0 hazards** |

数值验收在首次执行前沿用阶段 A 普通样例标准：对融合 FA 的 `atol=.004, rtol=.01`；小形状对 FP64 的 `atol=.04, rtol=.04` 加相对 L2 `<=.012`，数学零梯度单独检查绝对误差。没有为阶段 B 放宽阈值。

- 覆盖 `(Hq,Hkv)=(16,16)/(16,8)/(16,4)/(16,1)`、无历史、63/64/65-token 历史边界、短尾、多个独立序列、随机且组内不同的 Q/dO、自定义 scale、不同调用顺序及重复调用。
- 每次区域检查中，**current＋history 与 all dKV 逐位一致**，未选区域严格为零。设置仅一条序列 dO 非零时，其他序列三项梯度严格为零。另用错误的“只扫描当前 KV 的 dQ”作负对照，确保没有漏掉历史贡献。
- 阶段 B 数值样例中 dK/dV 与原融合 FA 逐位一致；dQ 最大绝对差 `4.8828125e-4`、最大相对 L2 差约 `2.6043e-5`。这些是实测样例结果，不承诺原子累加的逐位确定性。
- 小形状对独立 FP64 参考的最大相对 L2：dQ `0.002882`、dK `0.003351`、dV `0.003042`；原融合 FA 的对应最大值相同。
- 长形状额外验证 `Sq=2048, Sk=6144, Hq=16, Hkv=4/1`，对应当前 2048 tokens 加历史 4096 tokens；两种配置均通过原融合 FA 对照和区域合并检查。长形状没有运行 FP64 稠密参考，也没有测量性能。

实际 GPU 启动检查进一步确认区域选择不是“全算完再裁剪”：

| Sq / Sk，Hq=16、Hkv=4 | history KV tiles | current KV tiles | all KV tiles |
| --- | ---: | ---: | ---: |
| 129 / 1025（历史 896，边界对齐） | 14 | 3 | 17 |
| 129 / 1026（历史 897，边界不对齐） | 15 | 3 | 17 |
| 17 / 17（无历史） | 0，不启动主 kernel | 1 | 1 |

这些数字来自 profiler 记录中的实际 kernel 名称与 launch grid；未启动原融合 backward 或 dQ 转换 kernel。第二行明确显示边界 tile 的重复工作；这里没有用时间线推算收益。原始 trace 以 `.pt.trace.json` 归档在本机，按现有规则忽略 Git；可提交的 `validation.json` 保留启动次数、grid 和数值结果，manifest 保存文件 SHA256。

### 11.3 复现与后续边界

在 §9.4 相同 GPU 环境中，从仓库根目录执行：

```bash
python tools/build_dspp_fa_split.py
python -m pytest -q -s tests/unit_tests/dspp/test_fa_split.py \
  tests/unit_tests/dspp/test_fa_split_regions.py \
  tests/unit_tests/dspp/test_packed_attention.py tests/unit_tests/dspp/test_kv_state.py
compute-sanitizer --tool memcheck --error-exitcode 99 --kernel-name kns=dspp_split_detail \
  python -m pytest -q tests/unit_tests/dspp/test_fa_split_regions.py \
  -k 'regions_gqa_fused or varlen_regions or repeat_order'
compute-sanitizer --tool initcheck --error-exitcode 99 \
  python -m pytest -q tests/unit_tests/dspp/test_fa_split_regions.py -k 'varlen_regions and cuda'
compute-sanitizer --tool racecheck --error-exitcode 99 --kernel-name kns=dspp_split_detail \
  python -m pytest -q tests/unit_tests/dspp/test_fa_split_regions.py -k region_repeat_order
```

下一阶段仍是 C：接入现有 packed backward，验证 RoPE、QKV/输出投影、多层梯度与历史梯度路由。当前完成的 GQA/varlen kernel 验证，不等于这些模型级功能已通过，也不等于完整 stage dx 提前或历史计算已延后。本轮不修改外层研究计划或 `history-dkv/design.md`，不提交／推送 Git。

## 12. 阶段 B：chunk 场景的耗时与具体正确性证据（2026-10-16）

用户要求补充与阶段 A 类似的执行图、实际耗时和具体测试解释，因此新增本节；不进入阶段 C。脚本 [measure_dspp_fa_regions.py](../tools/measure_dspp_fa_regions.py) 生成输入、独立执行 attention、计时并核对梯度；[plot_dspp_fa_regions.py](../tools/plot_dspp_fa_regions.py) 绘图。材料集中在 [004-region-evidence-20261016](assets/fa-split/004-region-evidence-20261016/)。本节是新的局部实测，不改变 §11 当时没有采性能的记录。

### 12.1 测量对象与方法

在真实 L40 上，将生成的 6144-token Q/K/V 切成 3 个 2048-token query chunks，第 1／2／3 段分别使用长度 2048／4096／6144 的完整前缀 K/V。Hq=16、Hkv=16/4/1（MHA/GQA/MQA）、head dim=128、BF16、causal、dropout=0、seed=1234。输入是独立随机张量，不是模型投影输出或真实业务数据。

比较同一 chunk 的三条路径：原融合 FA、独立 dQ＋全部 dKV、独立 dQ＋当前 dKV＋历史 dKV。重复计时不包含 forward，也不包含将两个完整形状区域结果相加的操作；包含当前 backward API 的共享预处理、清零、转换、复制/GQA 归约，以及设备流上观察到的 CPU 提交间隔。每项预热 10 次，使用 CUDA events 计时 30 次，每轮轮换三条路径的测量顺序；报告中位数和 P10/P90。计时标记自身也有开销，因此这不是无仪器扰动的理想 kernel 吞吐。

完整路径总时间直接用起止 events 测量，不能将各部分中位数简单相加。另在重复计时结束后单独采 profiler，用 CUDA runtime correlation 关联 GPU kernels；图中时间是该单次样本，不能与重复计时中位数混用。图中额外的“历史先算”用于调用顺序正确性展示，未纳入三条路径的重复计时。

![阶段 B 真实 GPU 执行](assets/fa-split/004-region-evidence-20261016/gpu_region_execution.png)

### 12.2 耗时结果及其含义

第 3 个 chunk（当前 Q=2048、历史 KV=4096、总 KV=6144）的调用总耗时，单位 ms：

| 配置 | 原融合 FA | dQ＋全部 dKV | dQ＋当前＋历史 dKV | 后者 P10–P90 |
| --- | ---: | ---: | ---: | ---: |
| MHA，Hkv=16 | 1.643 | 2.551 | 2.680 | 2.653–2.704 |
| GQA，Hkv=4 | 1.625 | 2.437 | 2.569 | 2.553–2.590 |
| MQA，Hkv=1 | 1.604 | 2.421 | 2.540 | 2.532–2.565 |

GQA 第 3 段的拆分部分计时中位数：共享预处理 **0.043 ms**，完整 dQ **1.107 ms**，当前 dKV **0.342 ms**，历史 dKV **1.055 ms**。这些是各 API 部分的 event 时间，含其清零／转换／归约和提交间隔，不是单个主 kernel 的耗时。对应单次 profiler 中三个主 kernel 分别约 **1.014／0.303／0.970 ms**；两种口径不能互换。

从拆分调用起点到当前 dKV 完成，直接计时中位数为 **1.512 ms**；原融合调用为 **1.625 ms**。这只表示本次独立 attention 的完整 dQ 和当前 dKV 贡献在这一时刻完成，不是完整 stage dx；此处没有模型投影反向、后续层、历史梯度缓存消费者或流水线等待。历史计算仍须完成，区域拆分总耗时反而增加约 **58.1%**；相对 dQ＋全部 dKV，进一步划分当前／历史又增加约 **5.4%**。本次结果没有证明端到端收益。

![三个 chunk 的重复计时](assets/fa-split/004-region-evidence-20261016/repeated_backward_timing.png)

原阶段 A 的 359/263/301 μs 来自等长 Q/K=2048 的主 kernel 单次采样；这里第 3 段 K 长度为 6144，且表格是包含辅助操作的重复 API 计时，不能将两组数直接作性能回归比较。

### 12.3 测了什么，具体观察到什么

| 要排除的问题 | 对照方法与实际观察 |
| --- | --- |
| 只是改标签，实际仍算全部 dKV | 第 3 段的真实 launch grid：dQ 为 `[96,1,16]`，当前 dKV 为 `[32,1,16]`，历史 dKV 为 `[64,1,16]`；三种 head 配置都符合，仅选区相交的 KV tiles 被启动，拆分路径没有启动原融合 backward |
| 漏算、重复计算或写错区域 | 第 1／2／3 段分别与原融合 FA 对照；当前结果在历史区为零、历史结果在当前区为零；第 3 段三种 head 配置的合并 dK/dV 对原融合最大绝对差均为 0，dQ 不超过 `4.8828125e-4`；交换历史计算的先后顺序也通过 |
| GQA 共享 KV 的梯度归约不正确 | Hq=16，Hkv=16/4/1 各自与原生 FA 对照；小规模 FP64 参考通过显式展开 KV 并交给 autograd 求导，提供独立于本实现 head 归约的参照。§11 还覆盖 Hkv=8 |
| 各 chunk 的历史贡献累加后不正确 | 新增完整 145-token 序列切为 **63＋65＋17** 三段的检查：逐段算 Q 与前缀 KV，当前／历史结果按源位置手动以 FP32 累加。三种 head 配置下，组合 dQ/dK/dV 对“逐 chunk 原融合 FA 后同样累加”的最大绝对差均为 **0** |
| 切分对照也可能共享同一个错误 | 同一 145-token 序列再做一次完整 causal FA backward，并独立做 FP64 数学 autograd；三种 head 配置的拆分组合梯度对 FP64 最大相对 L2 为 **0.003077（0.308%）**，原整段 FA 最大为 **0.003058（0.306%）**，均通过预设阈值。拆分组合与整段 FA 不逐位相等，存在分段 BF16 舍入及累加顺序差异 |
| 非对齐边界、混装序列串扰 | 复用 §11 的直接证据：历史 897 时区域 tiles 为 15＋3，对完整 17，多出一个边界 tile；结果仍正确。多序列样例中只给一条序列非零 dO，其他序列梯度严格为零。此项来自 003 测试归档，不冒充 004 新采样 |

三段梯度组合检查是测量脚本里的独立 attention 数学验证，没有调用生产 KV cache 路由，也没有执行完整模型训练。它支持“切分后的当前／历史贡献计算与手动累加正确”，不能替代阶段 C 的缓存、RoPE、投影和多层集成验收。

### 12.4 复现与归档

新容器第一次采样在 CUDA 初始化处失败，未执行任何计时；失败日志保留。显式令 `LD_LIBRARY_PATH` 优先使用镜像的 `/usr/local/cuda/compat/lib.real` 后恢复 GPU 访问；宿主驱动仍为 550.120，没有改动宿主驱动或原训练容器。实际环境与源码 SHA256、各次原始时间、梯度误差和完整 kernel 事件保存在 `evidence.json`、`manifest.json`。原始 profiler trace 按已有规则不提交 Git。

在 §9.4 的环境中设置兼容库路径后运行（输出目录须不存在）：

```bash
export LD_LIBRARY_PATH=/usr/local/cuda/compat/lib.real:/usr/local/lib/python3.12/dist-packages/torch/lib:/usr/local/nvidia/lib64
python tools/measure_dspp_fa_regions.py --output /tmp/fa-region-evidence --warmup 10 --repeats 30
python tools/plot_dspp_fa_regions.py --evidence /tmp/fa-region-evidence/evidence.json \
  --font /path/to/NotoSansCJK-Regular.ttc
```

本轮只新增证据脚本、归档和本文，没有修改阶段 B kernel 或生产执行路径。

## 13. 阶段 C：接入真实 packed backward 与训练（2026-10-16）

用户明确要求执行阶段 C 后完成本节工作。§9–12 是各阶段当时的历史记录；其中“尚未接入模型／C 未开始”不再描述当前状态。当前交付是**拆分后立即执行的模型集成**，没有 H 延后队列，也没有提前发送完整 stage dx。

### 13.1 实际改动与执行合同

- [arguments.py](../megatron/arguments.py) 新增 `--dspp-split-attention-backward`，默认关闭；要求 DSPP、BF16、head dim=128、local transformer、无 ALiBi。沿用 DSPP 的 TP=CP=DP=1、dropout=0、无 activation checkpoint 等约束。
- [dspp_packed_attention.py](../megatron/core/kv_cache/dspp_packed_attention.py) 在前向保存开关和 metadata；backward 使用前向保存的 Q/K/V/O/LSE 和该次 dO，依次执行 `prepare → 完整 dQ → current dKV → history dKV → 区域结果相加 → 原有梯度路由`。host 端 cu_seqlens 来自冻结的 metadata，不读取后来被选中的 microbatch，也不新增 CUDA metadata 回读。
- 当前和历史区域输出在区域外均为零，合并后只调用一次 `distribute_key_value_grads`。当前 segment 收到的后续 chunks 梯度继续按原协议合并，再经原有 RoPE 反向及投影反向传播。GQA 缓存保持 Hkv 维度，不再次做 head 归约。所有历史计算完成后才从 attention backward 返回。
- [schedules.py](../megatron/core/pipeline_parallel/schedules.py) 只向单 stage 和 PP=3/VPP=2 的 KV state 传递开关；任务顺序、通信及缓存生命周期协议未改。阶段 B 的 CUDA kernel 本轮未修改。
- [run_dspp_b23_l40.sh](../examples/run_dspp_b23_l40.sh) 支持 `DSPP_SPLIT_ATTENTION_BACKWARD=1` 和可选 `NUM_QUERY_GROUPS`。不启用时沿用融合 backward。

正确性首版仍有逐序列 Python 分派、完整形状区域输出与合并、部分梯度工作区等开销，未做性能调优。支持范围为本轮验证的 L40、FA2 `2.7.4.post1`、BF16/d128、causal、无 dropout、非 fast RoPE；不据此扩展到 CP/TP、多种 dtype 或任意 head dimension。

### 13.2 模块与缓存正确性：具体检查及观察

新增 [test_packed_split.py](../tests/unit_tests/dspp/test_packed_split.py)。最终组合运行 **128 passed、0 skipped**：24 项 C 测试，加 104 项 A/B、原 packed/KV state 和单 stage runtime 回归。原始输出和逐 tensor 数值集中在 [005-stage-c-20261016](assets/fa-split/005-stage-c-20261016/)。

| 检查目标 | 实际覆盖与观察 |
| --- | --- |
| 真正进入拆分路径 | 拆分测试把原融合 backward 替换为报错函数；默认路径则令拆分入口报错，均正常完成。另检查前向保存开关，之后改 state 开关也不会切换该次 backward |
| packed 历史路由正确 | 长度 145/130/17/3、chunk=64，另含纯短序列 17/3；Hq=16，Hkv=16/8/4/1。检查每层每个 physical microbatch 只路由一次、历史累加 buffer 保留 Hkv、最后缓存排空。最终 dK/dV 对融合均逐位一致；dQ 最大绝对差 `3.8147e-6` |
| padding 与布局隔离 | padding 上给予非零上游梯度，仍检查输出及 Q/K/V 梯度的 padding 全为零；backward 前故意选择错误的 `current_meta`，验证使用前向保存布局 |
| RoPE、投影和多层梯度 | 1 层／3 层 block，包含仓库实际 RoPE、QKV/输出投影、LayerNorm、残差、GELU MLP；Hq=4、Hkv=4/2/1。同一 state 复用 2 iteration × 2 种 logical batch，比较每个输出、输入梯度和全部参数梯度 |
| 独立数学参照 | 对上述 block 做未切分整序列 FP64 autograd，独立实现 RoPE、显式展开 KV heads，权重/输入取同一 BF16 值。最终所有检查的拆分对 FP64 最大相对 L2 为 `0.00968971`（约 0.969%） |
| 接口与单 stage | 不支持的 dtype/dim 在修改缓存前报错；5 种非法 CLI 配置被拒绝；真实单 stage scheduler 搭配小模型完成 backward，检查开关传递和参数梯度有限 |
| GPU 内存访问 | 对实际 packed 路由的 8 项 MHA/GQA/MQA 用例运行 Compute Sanitizer memcheck，新扩展 kernel 过滤为 `kns=dspp_split_detail`，**0 errors**；不表示所有第三方 kernels 都经过本次检查 |

预设容限：拆分对融合 `atol=.004, rtol=.01`；多层模型对 FP64 `atol=.04, rtol=.04` 且逐 tensor 相对 L2 ≤ .03。多层测试包含 BF16 中间激活和梯度累加，因此与阶段 B 独立 attention 的 FP64 范数阈值不同；在首次运行前写入测试，并未按结果放宽。最终多层样例对融合最大绝对差为 0，初次测试出现过 `1.2207e-4`；保留两次日志，不将逐位一致当作确定性保证。

### 13.3 真实三卡训练对照

入口是实际 `pretrain_llama.py`，由 [validate_dspp_split_training.py](../tools/validate_dspp_split_training.py) 包装训练循环：在 optimizer 更新前保存全部模型参数梯度，保存各次 stage backward 返回的输入梯度，并记录实际拆分调用、混装任务与 state 排空。融合运行保存完整参考张量，拆分运行逐 tensor 对照，初始模型权重要求完全一致。

配置：3 张 L40，PP=3/VPP=2，TP=CP=DP=1；6 层、hidden=512、FFN=1024、Hq=4、d128、BF16、RoPE、RMSNorm、SwiGLU、dropout=0；合成训练序列长度 **193/129/33/17**、chunk=64、micro batch=4、global batch=8，seed=1234。沿用 `warmup-short-steady-long` 排序和 baseline packing。分别测试 MHA/Hkv=4、GQA/Hkv=2、MQA/Hkv=1，各自融合／拆分两组、每组 3 iteration。这里是变长、continuation 与短序列混装的正确性用例，不代表真实业务长度分布或长上下文性能规模。

下表为**首轮相同权重**下，跨三 rank、全部相关 tensor 的最大误差；绝对误差与相对 L2 的最大值可能来自不同 tensor：

| 结构 | 参数梯度最大绝对差 | 参数梯度最大相对 L2 | stage dx 最大绝对差 | stage dx 最大相对 L2 |
| --- | ---: | ---: | ---: | ---: |
| MHA，Hkv=4 | `4.88281e-4` | 0.2308% | `6.10352e-5` | 0.6828% |
| GQA，Hkv=2 | `1.70985e-9` | `8.52649e-9`（比值） | 0 | 0 |
| MQA，Hkv=1 | `9.45874e-11` | `4.13639e-10`（比值） | 0 | 0 |

连续更新 3 轮后，MHA 参数梯度最大绝对差为 `0.00252695`、最大相对 L2 为 **1.3470%**；stage dx 最大绝对差仍为 `6.10352e-5`、最大相对 L2 为 **1.3809%**。GQA/MQA 的上述误差上界未增加。后两轮包含优化器轨迹的舍入差异，不能全部解释为同权重下单次 backward 差异。MHA 首轮 loss 完全相同，第三轮融合／拆分 loss 分别为 `10.0158539 / 10.0225849`；GQA/MQA 三轮 loss 均一致。全部通过首次运行前规定的 `atol=.004, rtol=.01` 与相对 L2 ≤ .02 检查，没有调整阈值。

每种结构共比较 **117 个参数梯度 tensor、165 个 stage dx tensor**（按 iteration/rank 计数，非独立参数数量）；记录 **198 次实际拆分 attention backward、42 次含历史的混装 backward、36 次 state 排空**。三种结构合计比较 351 个参数梯度和 495 个 stage dx。检查覆盖完整模型梯度及 stage 输入梯度，已超出阶段 B 的独立 attention；但 stage dx 的交付时机仍遵循原任务流程。

### 13.4 复现、归档与使用

使用 §9.4 的容器／Python 环境，固定扩展依赖已缓存时执行下列命令。`python` 应指向 `/workspace/src/venvs/megatron/bin/python`；本机目录 `/home/cuiym` 在容器内挂载为 `/workspace`。

```bash
export USER=cuiym
export LD_LIBRARY_PATH=/usr/local/cuda/compat/lib.real:/usr/local/lib/python3.12/dist-packages/torch/lib:/usr/local/nvidia/lib64
export TORCHINDUCTOR_CACHE_DIR=/tmp/dspp-split-inductor
export TRITON_CACHE_DIR=/tmp/dspp-stage-c-triton
export TORCH_EXTENSIONS_DIR=/workspace/.cache/torch_extensions
export DSPP_FA_SPLIT_CACHE=/workspace/.cache/dspp-fa-split
python tools/build_dspp_fa_split.py
python -m pytest -q -s tests/unit_tests/dspp/test_packed_split.py \
  tests/unit_tests/dspp/test_fa_split.py tests/unit_tests/dspp/test_fa_split_regions.py \
  tests/unit_tests/dspp/test_packed_attention.py tests/unit_tests/dspp/test_kv_state.py \
  tests/unit_tests/dspp/test_training_runtime.py
compute-sanitizer --tool memcheck --error-exitcode 99 --kernel-name kns=dspp_split_detail \
  python -m pytest -q tests/unit_tests/dspp/test_packed_split.py -k real_route_and_padding
DSPP_SPLIT_CHECK_ROOT=/tmp/dspp-stage-c-new \
DSPP_SPLIT_CHECK_SNAPSHOT_ROOT=/workspace/.cache/dspp-stage-c-new \
  bash examples/validate_dspp_split_training.sh
```

两处输出目录须尚不存在。脚本 [validate_dspp_split_training.sh](../examples/validate_dspp_split_training.sh) 包含数据生成、完整参数与六组运行；它只用于正确性，不用于计时。首次 PP 启动因 Triton 默认尝试写 `/.triton` 在训练前失败；归档保留失败日志，指定可写的 cache 路径后重跑全部对照，未改宿主驱动或原训练容器。

[validation.json](assets/fa-split/005-stage-c-20261016/validation.json) 保存逐项模块误差与 PP 汇总；`pp/` 保存每个 rank/iteration 的对照 JSON 与完整训练日志；[manifest.json](assets/fa-split/005-stage-c-20261016/manifest.json) 记录环境、命令、源码/证据/输入及外部参考张量的 SHA256，`source-snapshot.tar.gz` 保存对应源码。完整参考张量存于本机 `/home/cuiym/.cache/dspp-fa-split/stage-c-pp-20261016-r2/`，不复制进 Git。日志中的 iteration 时间受到张量转 CPU、保存与逐项比较的显著扰动，不能用于加速比或拆分开销结论。

已配置数据路径和运行环境后，原训练 launcher 可这样打开拆分：

```bash
HIDDEN_SIZE=512 FFN_HIDDEN_SIZE=1024 NUM_ATTENTION_HEADS=4 NUM_QUERY_GROUPS=2 \
DSPP_SPLIT_ATTENTION_BACKWARD=1 bash examples/run_dspp_b23_l40.sh
```

该示例 head dim=128；原 launcher 默认 hidden=64、Hq=4，其 d16 不支持拆分。`NUM_QUERY_GROUPS=2` 会改变模型结构，融合对照必须使用同样配置，不能拿之前不同结构的日志作基线。这里完成的是 A/B/C 拆分计划；后续若研究 dx 提前交付，需要另设计历史任务状态生命周期、消费者依赖和调度，再评估端到端收益。
